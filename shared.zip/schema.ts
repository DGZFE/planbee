import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const UserRole = {
  OWNER: "owner",
  STUDENT: "student",
  TEACHER: "teacher",
  ADMIN: "admin",
  PRINCIPAL: "principal",
  SUPERINTENDENT: "superintendent",
} as const;

export const districts = pgTable("districts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const schools = pgTable("schools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  districtId: integer("district_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const registrationKeys = pgTable("registration_keys", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  districtName: text("district_name").notNull(),
  createdBy: integer("created_by").notNull(),
  usedBy: integer("used_by"),
  createdAt: timestamp("created_at").defaultNow(),
  usedAt: timestamp("used_at"),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: Object.values(UserRole) }).notNull(),
  points: integer("points").default(0),
  schoolId: integer("school_id"),
  districtId: integer("district_id"),
  registrationKey: text("registration_key"),
});

// Create insert schema for registration key verification
export const registrationKeySchema = z.object({
  key: z.string().min(1, "Registration key is required"),
  districtName: z.string().min(1, "District name is required"),
});

export const insertUserSchema = createInsertSchema(users);

// Extend user schema to include registration key for registration
export const registrationSchema = z.object({
  ...insertUserSchema.shape,
  registrationKey: z.string().min(1, "Registration key is required"),
});

export const customRoles = pgTable("custom_roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdBy: integer("created_by").notNull(),
  schoolId: integer("school_id").notNull(),
  permissions: text("permissions").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  teacherId: integer("teacher_id").notNull(),
  schoolId: integer("school_id").notNull(),
});

export const classEnrollments = pgTable("class_enrollments", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull(),
  studentId: integer("student_id").notNull(),
});

export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  dueDate: timestamp("due_date").notNull(),
  classId: integer("class_id").notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  senderId: integer("sender_id").notNull(),
  classId: integer("class_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const iframeContent = pgTable("iframe_content", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  description: text("description"),
  createdBy: integer("created_by").notNull(),
  classId: integer("class_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRegistrationKeySchema = createInsertSchema(registrationKeys);
export const insertDistrictSchema = createInsertSchema(districts);
export const insertSchoolSchema = createInsertSchema(schools);
export const insertClassSchema = createInsertSchema(classes);
export const insertAssignmentSchema = createInsertSchema(assignments);
export const insertMessageSchema = createInsertSchema(messages);
export const insertIframeContentSchema = createInsertSchema(iframeContent);
export const insertCustomRoleSchema = createInsertSchema(customRoles);

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type District = typeof districts.$inferSelect;
export type School = typeof schools.$inferSelect;
export type Class = typeof classes.$inferSelect;
export type Assignment = typeof assignments.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type IframeContent = typeof iframeContent.$inferSelect;
export type CustomRole = typeof customRoles.$inferSelect;
export type RegistrationKey = typeof registrationKeys.$inferSelect;
export type InsertRegistrationKey = z.infer<typeof insertRegistrationKeySchema>;