import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertUserSchema, insertAssignmentSchema, insertMessageSchema } from "@shared/schema";
import { insertIframeContentSchema } from "@shared/schema";
import { insertCustomRoleSchema, registrationKeySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);
  const httpServer = createServer(app);

  // WebSocket setup
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // JSON parsing error handler
  app.use((err: any, req: any, res: any, next: any) => {
    if (err instanceof SyntaxError && 'body' in err) {
      return res.status(400).json({ error: "Invalid JSON" });
    }
    next();
  });

  // General error handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error(err.stack);
    res.status(500).json({ error: "Internal server error" });
  });

  // Registration key verification
  app.post("/api/verify-key", async (req, res) => {
    try {
      // Set content type explicitly
      res.setHeader('Content-Type', 'application/json');

      const parsed = registrationKeySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid registration key format" });
      }

      const key = await storage.getRegistrationKey(parsed.data.key);
      if (!key || key.usedBy !== null) {
        return res.status(400).json({ error: "Invalid or used registration key" });
      }

      return res.json({ valid: true });
    } catch (error) {
      console.error('Error verifying key:', error);
      return res.status(500).json({ error: "Failed to verify registration key" });
    }
  });

  // Registration key management
  app.get("/api/registration-keys", async (req, res) => {
    try {
      if (!req.user || (req.user.role !== "owner" && req.user.role !== "superintendent")) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const keys = await storage.getRegistrationKeys();
      res.json(keys);
    } catch (error) {
      console.error('Error fetching registration keys:', error);
      res.status(500).json({ error: "Failed to fetch registration keys" });
    }
  });

  app.post("/api/registration-keys", async (req, res) => {
    try {
      if (!req.user || (req.user.role !== "owner" && req.user.role !== "superintendent")) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const key = await storage.createRegistrationKey(
        Math.random().toString(36).substring(2, 8).toUpperCase(),
        req.user.id,
        req.body.districtName
      );
      res.status(201).json(key);
    } catch (error) {
      console.error('Error creating registration key:', error);
      res.status(500).json({ error: "Failed to create registration key" });
    }
  });

  // User registration with key verification
  app.post("/api/register", async (req, res) => {
    try {
      const registrationKey = await storage.getRegistrationKey(req.body.registrationKey);
      if (!registrationKey || registrationKey.usedBy !== null) {
        return res.status(400).json({ error: "Invalid or used registration key" });
      }

      const parsed = insertUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid user data" });
      }

      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ error: "Username already exists" });
      }

      const user = await storage.createUser(parsed.data);
      await storage.useRegistrationKey(req.body.registrationKey, user.id);

      req.login(user, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json(user);
      });
    } catch (error) {
      console.error('Error registering user:', error);
      res.status(500).json({ error: "Failed to register user" });
    }
  });

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === 'chat') {
          const newMessage = await storage.createMessage(message.data);
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({ type: 'chat', data: newMessage }));
            }
          });
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected');
    });
  });


  // District and School routes
  app.post("/api/districts", async (req, res) => {
    if (!req.user || req.user.role !== "superintendent") {
      return res.sendStatus(401);
    }

    const district = await storage.createDistrict(req.body.name);
    res.status(201).json(district);
  });

  app.get("/api/districts", async (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const districts = await storage.getDistricts();
    res.json(districts);
  });

  app.post("/api/schools", async (req, res) => {
    if (!req.user || req.user.role !== "superintendent") {
      return res.sendStatus(401);
    }

    const school = await storage.createSchool(req.body.name, req.body.districtId);
    res.status(201).json(school);
  });

  app.get("/api/districts/:districtId/schools", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const schools = await storage.getSchoolsByDistrict(parseInt(req.params.districtId));
    res.json(schools);
  });

  // Custom Role routes
  app.post("/api/custom-roles", async (req, res) => {
    if (!req.user || req.user.role !== "principal") {
      return res.sendStatus(401);
    }

    const parsed = insertCustomRoleSchema.safeParse({
      ...req.body,
      createdBy: req.user.id,
    });

    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid custom role data" });
    }

    const role = await storage.createCustomRole(parsed.data);
    res.status(201).json(role);
  });

  app.get("/api/schools/:schoolId/custom-roles", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const roles = await storage.getCustomRolesBySchool(parseInt(req.params.schoolId));
    res.json(roles);
  });

  // Class routes
  app.get("/api/classes", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      let classes;
      if (req.user.role === "student") {
        classes = await storage.getClassesByStudent(req.user.id);
      } else if (req.user.role === "teacher") {
        classes = await storage.getClassesByTeacher(req.user.id);
      } else {
        classes = await storage.getClassesByTeacher(0); // For admin, get all classes
      }
      res.json(classes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch classes" });
    }
  });

  app.post("/api/classes", async (req, res) => {
    if (!req.user || req.user.role !== "teacher") return res.sendStatus(401);

    const newClass = await storage.createClass(
      req.body.name,
      req.user.id,
      req.body.schoolId
    );
    res.status(201).json(newClass);
  });

  //Assignment routes
  app.post("/api/assignments", async (req, res) => {
    if (!req.user || req.user.role !== "teacher") return res.sendStatus(401);

    const parsed = insertAssignmentSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid assignment data" });
    }

    const assignment = await storage.createAssignment(parsed.data);
    res.status(201).json(assignment);
  });

  app.get("/api/assignments/:classId", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const assignments = await storage.getAssignmentsByClass(
      parseInt(req.params.classId)
    );
    res.json(assignments);
  });

  app.post("/api/points/:userId", async (req, res) => {
    if (!req.user || req.user.role !== "teacher") return res.sendStatus(401);

    const updatedUser = await storage.updateUserPoints(
      parseInt(req.params.userId),
      req.body.points
    );
    res.json(updatedUser);
  });

  // Iframe content routes
  app.post("/api/iframe-content", async (req, res) => {
    if (!req.user || (req.user.role !== "teacher" && req.user.role !== "admin" && req.user.role !== "superintendent")) {
      return res.sendStatus(401);
    }

    const parsed = insertIframeContentSchema.safeParse({
      ...req.body,
      createdBy: req.user.id,
    });

    if (!parsed.success) {
      return res.status(400).json({ error: "Invalid iframe content data" });
    }

    const content = await storage.createIframeContent(parsed.data);
    res.status(201).json(content);
  });

  app.get("/api/iframe-content/:classId", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const content = await storage.getIframeContentByClass(parseInt(req.params.classId));
    res.json(content);
  });

  return httpServer;
}