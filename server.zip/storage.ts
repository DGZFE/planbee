import { type User, type InsertUser, type Class, type Message, type Assignment, type IframeContent, type District, type School, type CustomRole, type RegistrationKey, type InsertRegistrationKey, UserRole } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { hashPassword } from "./crypto";
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User>;

  // District operations
  createDistrict(name: string): Promise<District>;
  getDistricts(): Promise<District[]>;

  // School operations
  createSchool(name: string, districtId: number): Promise<School>;
  getSchoolsByDistrict(districtId: number): Promise<School[]>;

  // Custom Role operations
  createCustomRole(role: CustomRole): Promise<CustomRole>;
  getCustomRolesBySchool(schoolId: number): Promise<CustomRole[]>;

  // Class operations
  createClass(name: string, teacherId: number, schoolId: number): Promise<Class>;
  getClassesByTeacher(teacherId: number): Promise<Class[]>;
  getClassesByStudent(studentId: number): Promise<Class[]>;
  enrollStudent(classId: number, studentId: number): Promise<void>;

  // Assignment operations
  createAssignment(assignment: Assignment): Promise<Assignment>;
  getAssignmentsByClass(classId: number): Promise<Assignment[]>;

  // Message operations
  createMessage(message: Message): Promise<Message>;
  getMessagesByClass(classId: number): Promise<Message[]>;

  // IFrame Content operations
  createIframeContent(content: IframeContent): Promise<IframeContent>;
  getIframeContentByClass(classId: number): Promise<IframeContent[]>;

  // Registration key operations
  createRegistrationKey(key: string, createdBy: number, districtName: string): Promise<RegistrationKey>;
  getRegistrationKey(key: string): Promise<RegistrationKey | undefined>;
  getRegistrationKeys(): Promise<RegistrationKey[]>;
  useRegistrationKey(key: string, userId: number): Promise<void>;

  // Session store
  sessionStore: session.Store;
  initializeStorage(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private districts: Map<number, District>;
  private schools: Map<number, School>;
  private classes: Map<number, Class>;
  private assignments: Map<number, Assignment>;
  private messages: Map<number, Message>;
  private iframeContents: Map<number, IframeContent>;
  private customRoles: Map<number, CustomRole>;
  private enrollments: Map<string, boolean>;
  private registrationKeys: Map<string, RegistrationKey>;
  private currentId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.districts = new Map();
    this.schools = new Map();
    this.classes = new Map();
    this.assignments = new Map();
    this.messages = new Map();
    this.iframeContents = new Map();
    this.customRoles = new Map();
    this.enrollments = new Map();
    this.registrationKeys = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async initializeStorage(): Promise<void> {
    try {
      // Create owner account
      const ownerId = this.currentId++;
      const hashedPassword = await hashPassword("owner");
      const ownerUser: User = {
        id: ownerId,
        username: "owner",
        password: hashedPassword,
        role: UserRole.OWNER,
        points: 0,
        schoolId: null,
        districtId: null,
        registrationKey: "DG8AB"
      };
      this.users.set(ownerId, ownerUser);

      // Create initial registration key
      const registrationKey: RegistrationKey = {
        id: this.currentId++,
        key: "DG8AB",
        districtName: "Default District", // Added districtName
        createdBy: ownerId,
        createdAt: new Date(),
        usedBy: null,
        usedAt: null
      };
      this.registrationKeys.set("DG8AB", registrationKey);

      console.log("Storage initialized with owner account");
    } catch (error) {
      console.error("Failed to initialize storage:", error);
      throw error;
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const hashedPassword = await hashPassword(insertUser.password);
    const user = { ...insertUser, id, password: hashedPassword };
    this.users.set(id, user);
    return user;
  }

  async updateUserPoints(userId: number, points: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");

    const updatedUser = { ...user, points: (user.points || 0) + points };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async createDistrict(name: string): Promise<District> {
    const id = this.currentId++;
    const district = { id, name, createdAt: new Date() };
    this.districts.set(id, district);
    return district;
  }

  async getDistricts(): Promise<District[]> {
    return Array.from(this.districts.values());
  }

  async createSchool(name: string, districtId: number): Promise<School> {
    const id = this.currentId++;
    const school = { id, name, districtId, createdAt: new Date() };
    this.schools.set(id, school);
    return school;
  }

  async getSchoolsByDistrict(districtId: number): Promise<School[]> {
    return Array.from(this.schools.values()).filter(
      (s) => s.districtId === districtId
    );
  }

  async createCustomRole(role: CustomRole): Promise<CustomRole> {
    const id = this.currentId++;
    const newRole = { ...role, id, createdAt: new Date() };
    this.customRoles.set(id, newRole);
    return newRole;
  }

  async getCustomRolesBySchool(schoolId: number): Promise<CustomRole[]> {
    return Array.from(this.customRoles.values()).filter(
      (r) => r.schoolId === schoolId
    );
  }

  async createClass(name: string, teacherId: number, schoolId: number): Promise<Class> {
    const id = this.currentId++;
    const newClass = { id, name, teacherId, schoolId };
    this.classes.set(id, newClass);
    return newClass;
  }

  async getClassesByTeacher(teacherId: number): Promise<Class[]> {
    return Array.from(this.classes.values()).filter(
      (c) => c.teacherId === teacherId
    );
  }

  async getClassesByStudent(studentId: number): Promise<Class[]> {
    const enrolledClassIds = Array.from(this.enrollments.keys())
      .filter(key => key.split('-')[1] === studentId.toString())
      .map(key => parseInt(key.split('-')[0]));

    return Array.from(this.classes.values()).filter(
      c => enrolledClassIds.includes(c.id)
    );
  }

  async enrollStudent(classId: number, studentId: number): Promise<void> {
    this.enrollments.set(`${classId}-${studentId}`, true);
  }

  async createAssignment(assignment: Assignment): Promise<Assignment> {
    const id = this.currentId++;
    const newAssignment = { ...assignment, id };
    this.assignments.set(id, newAssignment);
    return newAssignment;
  }

  async getAssignmentsByClass(classId: number): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).filter(
      (a) => a.classId === classId
    );
  }

  async createMessage(message: Message): Promise<Message> {
    const id = this.currentId++;
    const newMessage = { ...message, id };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async getMessagesByClass(classId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((m) => m.classId === classId)
      .sort((a, b) => {
        if (!a.timestamp || !b.timestamp) return 0;
        return a.timestamp.getTime() - b.timestamp.getTime();
      });
  }

  async createIframeContent(content: IframeContent): Promise<IframeContent> {
    const id = this.currentId++;
    const newContent = { ...content, id };
    this.iframeContents.set(id, newContent);
    return newContent;
  }

  async getIframeContentByClass(classId: number): Promise<IframeContent[]> {
    return Array.from(this.iframeContents.values())
      .filter(content => content.classId === classId)
      .sort((a, b) => {
        if (!a.createdAt || !b.createdAt) return 0;
        return b.createdAt.getTime() - a.createdAt.getTime();
      });
  }

  async createRegistrationKey(key: string, createdBy: number, districtName: string): Promise<RegistrationKey> {
    const newKey: RegistrationKey = {
      id: this.currentId++,
      key,
      districtName,
      createdBy,
      createdAt: new Date(),
      usedBy: null,
      usedAt: null
    };
    this.registrationKeys.set(key, newKey);
    return newKey;
  }

  async getRegistrationKey(key: string): Promise<RegistrationKey | undefined> {
    return this.registrationKeys.get(key);
  }

  async useRegistrationKey(key: string, userId: number): Promise<void> {
    const registrationKey = await this.getRegistrationKey(key);
    if (!registrationKey) return;

    registrationKey.usedBy = userId;
    registrationKey.usedAt = new Date();
    this.registrationKeys.set(key, registrationKey);
  }

  async getRegistrationKeys(): Promise<RegistrationKey[]> {
    return Array.from(this.registrationKeys.values());
  }
}

export const storage = new MemStorage();
// Initialize storage
storage.initializeStorage().catch(console.error);