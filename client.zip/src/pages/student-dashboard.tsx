import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import HomeworkCard from "@/components/assignments/homework-card";
import ChatWindow from "@/components/chat/chat-window";
import DayPlanner from "@/components/planner/day-planner";
import { BookOpen, MessageSquare, Calendar, Monitor } from "lucide-react";
import IframeManager from "@/components/iframe/iframe-manager";

export default function StudentDashboard() {
  const { user } = useAuth();

  const { data: classes } = useQuery({
    queryKey: ["/api/classes"],
  });

  const { data: assignments } = useQuery({
    queryKey: ["/api/assignments", classes?.[0]?.id],
    enabled: !!classes?.[0]?.id,
  });

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Welcome, {user?.username}!</h1>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">Points:</span>
            <span className="font-bold text-lg">{user?.points || 0}</span>
          </div>
        </div>

        <Tabs defaultValue="assignments" className="space-y-4">
          <TabsList>
            <TabsTrigger value="assignments" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Assignments
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="planner" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Planner
            </TabsTrigger>
            <TabsTrigger value="content" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Content
            </TabsTrigger>
          </TabsList>

          <TabsContent value="assignments">
            <Card>
              <CardHeader>
                <CardTitle>Your Assignments</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-4">
                    {assignments?.map((assignment) => (
                      <HomeworkCard key={assignment.id} assignment={assignment} />
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="chat">
            <Card>
              <CardHeader>
                <CardTitle>Class Chat</CardTitle>
              </CardHeader>
              <CardContent>
                <ChatWindow classId={classes?.[0]?.id} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="planner">
            <Card>
              <CardHeader>
                <CardTitle>Day Planner</CardTitle>
              </CardHeader>
              <CardContent>
                <DayPlanner />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="content">
            <Card>
              <CardHeader>
                <CardTitle>External Content</CardTitle>
              </CardHeader>
              <CardContent>
                {classes?.map((class_) => (
                  <div key={class_.id} className="mb-8">
                    <h3 className="font-semibold mb-4">{class_.name}</h3>
                    <IframeManager classId={class_.id} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}