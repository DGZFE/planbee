import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import HomeworkCard from "@/components/assignments/homework-card";
import ChatWindow from "@/components/chat/chat-window";
import DayPlanner from "@/components/planner/day-planner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { BookOpen, MessageSquare, Calendar, Plus, Monitor } from "lucide-react";
import IframeManager from "@/components/iframe/iframe-manager";

export default function TeacherDashboard() {
  const { user } = useAuth();

  const { data: classes } = useQuery({
    queryKey: ["/api/classes"],
  });

  const form = useForm({
    defaultValues: {
      name: "",
    },
  });

  const createClass = async (data: { name: string }) => {
    await apiRequest("POST", "/api/classes", data);
    queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Teacher Dashboard</h1>

          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Create Class
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Class</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(createClass)} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Class Name</Label>
                    <Input id="name" {...form.register("name")} />
                  </div>
                  <Button type="submit">Create</Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <Tabs defaultValue="assignments" className="space-y-4">
          <TabsList>
            <TabsTrigger value="assignments" className="flex items-center gap-2">
              <BookOpen className="h-4 w-4" />
              Assignments
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="planner" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Planner
            </TabsTrigger>
            <TabsTrigger value="content" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Content
            </TabsTrigger>
          </TabsList>

          <TabsContent value="assignments">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Class Assignments</CardTitle>
                <Button variant="outline">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Assignment
                </Button>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px] pr-4">
                  {classes?.map((class_) => (
                    <div key={class_.id} className="space-y-4">
                      <h3 className="font-semibold">{class_.name}</h3>
                      <HomeworkCard
                        assignment={{
                          id: 1,
                          title: "Sample Assignment",
                          description: "Description",
                          dueDate: new Date(),
                          classId: class_.id,
                        }}
                        isTeacher
                      />
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="chat">
            <Card>
              <CardHeader>
                <CardTitle>Class Chats</CardTitle>
              </CardHeader>
              <CardContent>
                {classes?.map((class_) => (
                  <div key={class_.id} className="mb-8">
                    <h3 className="font-semibold mb-4">{class_.name}</h3>
                    <ChatWindow classId={class_.id} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="planner">
            <Card>
              <CardHeader>
                <CardTitle>Day Planner</CardTitle>
              </CardHeader>
              <CardContent>
                <DayPlanner />
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="content">
            <Card>
              <CardHeader>
                <CardTitle>External Content</CardTitle>
              </CardHeader>
              <CardContent>
                {classes?.map((class_) => (
                  <div key={class_.id} className="mb-8">
                    <h3 className="font-semibold mb-4">{class_.name}</h3>
                    <IframeManager classId={class_.id} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}