import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema, UserRole } from "@shared/schema";
import { Redirect, useLocation } from "wouter";
import { useState } from "react";
import { School } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const { toast } = useToast();
  const [isLogin, setIsLogin] = useState(true);
  const [isKeyVerified, setIsKeyVerified] = useState(false);
  const [, setLocation] = useLocation();

  const form = useForm({
    resolver: zodResolver(
      isLogin
        ? insertUserSchema.pick({ username: true, password: true })
        : insertUserSchema.extend({
            registrationKey: insertUserSchema.shape.registrationKey,
          })
    ),
    defaultValues: {
      username: "",
      password: "",
      registrationKey: "",
      role: UserRole.SUPERINTENDENT,
    },
  });

  if (user) {
    switch (user.role) {
      case UserRole.OWNER:
        return <Redirect to="/owner" />;
      case UserRole.STUDENT:
        return <Redirect to="/" />;
      case UserRole.TEACHER:
        return <Redirect to="/teacher" />;
      case UserRole.ADMIN:
        return <Redirect to="/admin" />;
      case UserRole.SUPERINTENDENT:
        return <Redirect to="/admin" />;
    }
  }

  const verifyKey = async (registrationKey: string) => {
    try {
      const response = await apiRequest("POST", "/api/verify-key", { key: registrationKey });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: "Invalid response from server" }));
        throw new Error(errorData.error || "Failed to verify key");
      }

      const data = await response.json();
      if (data.valid) {
        setIsKeyVerified(true);
        toast({
          title: "Registration key verified",
          description: "You can now proceed with registration.",
        });
      } else {
        toast({
          title: "Invalid registration key",
          description: "Please check your registration key and try again.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Verification failed",
        description: error.message || "Failed to verify registration key",
        variant: "destructive",
      });
    }
  };

  const onSubmit = async (data: any) => {
    if (isLogin) {
      loginMutation.mutate(data);
    } else {
      if (!isKeyVerified) {
        await verifyKey(data.registrationKey);
        return;
      }
      registerMutation.mutate(data);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid md:grid-cols-2 gap-8">
        <div className="flex flex-col justify-center space-y-6">
          <div className="flex items-center gap-2">
            <School className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold">Plan Bee</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            A comprehensive platform for managing schools, districts, and education.
          </p>
          <div className="flex gap-4">
            <Button 
              variant="outline" 
              onClick={() => setLocation("/auth/superintendent")}
              className="flex-1"
            >
              Superintendent Login
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setLocation("/auth/teacher")}
              className="flex-1"
            >
              Teacher Login
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setLocation("/auth/student")}
              className="flex-1"
            >
              Student Login
            </Button>
          </div>
        </div>

        <Card className="w-full">
          <CardHeader>
            <CardTitle>{isLogin ? "Login" : "Register"}</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                {!isLogin && !isKeyVerified && (
                  <div className="space-y-2">
                    <Label htmlFor="registrationKey">Registration Key</Label>
                    <Input
                      id="registrationKey"
                      {...form.register("registrationKey")}
                      placeholder="Enter your registration key"
                    />
                    <p className="text-sm text-muted-foreground">
                      A registration key is required to create a new account.
                    </p>
                  </div>
                )}

                {(isLogin || isKeyVerified) && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        {...form.register("username")}
                        placeholder="Enter your username"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        {...form.register("password")}
                        placeholder="Enter your password"
                      />
                    </div>
                  </>
                )}

                <Button
                  type="submit"
                  className="w-full"
                  disabled={loginMutation.isPending || registerMutation.isPending}
                >
                  {isLogin
                    ? "Login"
                    : isKeyVerified
                      ? "Complete Registration"
                      : "Verify Key"}
                </Button>

                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => {
                    setIsLogin(!isLogin);
                    setIsKeyVerified(false);
                    form.reset();
                  }}
                >
                  {isLogin ? "Need an account? Register" : "Have an account? Login"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}