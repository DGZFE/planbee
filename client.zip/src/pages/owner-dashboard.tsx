import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Key, MessageSquare } from "lucide-react";
import ChatWindow from "@/components/chat/chat-window";

const createKeySchema = z.object({
  districtName: z.string().min(1, "District name is required"),
});

export default function OwnerDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(createKeySchema),
    defaultValues: {
      districtName: "",
    },
  });

  const { data: registrationKeys } = useQuery({
    queryKey: ["/api/registration-keys"],
  });

  const createKeyMutation = useMutation({
    mutationFn: async (data: { districtName: string }) => {
      const res = await apiRequest("POST", "/api/registration-keys", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/registration-keys"] });
      form.reset();
      toast({
        title: "Success",
        description: "Registration key created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    createKeyMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">Owner Dashboard</h1>
        </div>

        <Tabs defaultValue="keys" className="space-y-4">
          <TabsList>
            <TabsTrigger value="keys" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Registration Keys
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Superintendent Chat
            </TabsTrigger>
          </TabsList>

          <TabsContent value="keys">
            <Card>
              <CardHeader>
                <CardTitle>Create Registration Key</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="districtName">District Name</Label>
                      <Input
                        id="districtName"
                        {...form.register("districtName")}
                        placeholder="Enter district name"
                      />
                    </div>
                    <Button type="submit" disabled={createKeyMutation.isPending}>
                      Generate Key
                    </Button>
                  </form>
                </Form>

                <div className="mt-8">
                  <h3 className="font-semibold mb-4">Generated Keys</h3>
                  <div className="space-y-4">
                    {registrationKeys?.map((key: any) => (
                      <Card key={key.id}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{key.districtName}</p>
                              <p className="text-sm text-muted-foreground">Key: {key.key}</p>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {key.usedBy ? "Used" : "Available"}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="chat">
            <Card>
              <CardHeader>
                <CardTitle>Chat with Superintendents</CardTitle>
              </CardHeader>
              <CardContent>
                <ChatWindow specialChannel="owner-superintendents" />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
