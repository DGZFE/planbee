import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";
import { Message } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ChatWindowProps {
  classId?: number;
  specialChannel?: string;
}

export default function ChatWindow({ classId, specialChannel }: ChatWindowProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [message, setMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: initialMessages } = useQuery<Message[]>({
    queryKey: [specialChannel ? `/api/messages/${specialChannel}` : "/api/messages", classId],
    enabled: !!(classId || specialChannel),
  });

  useEffect(() => {
    if (initialMessages) {
      setMessages(initialMessages);
    }
  }, [initialMessages]);

  useEffect(() => {
    if (!classId && !specialChannel) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log("WebSocket connection established");
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "chat") {
          if (
            (specialChannel && data.data.specialChannel === specialChannel) ||
            (!specialChannel && data.data.classId === classId)
          ) {
            setMessages((prev) => [...prev, data.data]);
          }
        }
      } catch (error) {
        console.error("Error parsing message:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      toast({
        title: "Connection Error",
        description: "Failed to connect to chat server",
        variant: "destructive",
      });
    };

    ws.onclose = () => {
      console.log("WebSocket connection closed");
    };

    setSocket(ws);

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [classId, specialChannel, toast]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!socket || !message.trim() || !user) return;

    const newMessage = {
      content: message,
      senderId: user.id,
      classId: classId || null,
      specialChannel: specialChannel || null,
      timestamp: new Date(),
    };

    try {
      socket.send(JSON.stringify({ type: "chat", data: newMessage }));
      setMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    }
  };

  if (!classId && !specialChannel) return null;

  return (
    <div className="h-[500px] flex flex-col">
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4" ref={scrollRef}>
          {messages.map((msg) => (
            <Card
              key={msg.id}
              className={`p-3 max-w-[80%] ${
                msg.senderId === user?.id ? "ml-auto bg-primary text-primary-foreground" : ""
              }`}
            >
              <p className="text-sm">{msg.content}</p>
              <span className="text-xs opacity-70">
                {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString() : ""}
              </span>
            </Card>
          ))}
        </div>
      </ScrollArea>

      <form onSubmit={sendMessage} className="p-4 flex gap-2">
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Type your message..."
        />
        <Button type="submit" disabled={!message.trim()}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}