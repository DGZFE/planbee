import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Trash2 } from "lucide-react";

interface Event {
  id: number;
  title: string;
  time: string;
  date: Date;
}

interface DayPlannerProps {
  isAdmin?: boolean;
}

export default function DayPlanner({ isAdmin }: DayPlannerProps) {
  const [date, setDate] = useState<Date>(new Date());
  const [events, setEvents] = useState<Event[]>([]);
  const [newEvent, setNewEvent] = useState({ title: "", time: "" });

  const addEvent = () => {
    if (!newEvent.title || !newEvent.time) return;

    setEvents([
      ...events,
      {
        id: Date.now(),
        title: newEvent.title,
        time: newEvent.time,
        date: date,
      },
    ]);

    setNewEvent({ title: "", time: "" });
  };

  const removeEvent = (id: number) => {
    setEvents(events.filter((event) => event.id !== id));
  };

  const todayEvents = events.filter(
    (event) => event.date.toDateString() === date.toDateString()
  );

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div>
        <Calendar
          mode="single"
          selected={date}
          onSelect={(date) => date && setDate(date)}
          className="rounded-md border"
        />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">
            Events for {date.toLocaleDateString()}
          </h3>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Event
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Event</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <Input
                  placeholder="Event title"
                  value={newEvent.title}
                  onChange={(e) =>
                    setNewEvent({ ...newEvent, title: e.target.value })
                  }
                />
                <Input
                  type="time"
                  value={newEvent.time}
                  onChange={(e) =>
                    setNewEvent({ ...newEvent, time: e.target.value })
                  }
                />
                <Button onClick={addEvent}>Add Event</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <ScrollArea className="h-[300px]">
          <div className="space-y-2">
            {todayEvents.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                No events scheduled for this day
              </p>
            ) : (
              todayEvents
                .sort((a, b) => a.time.localeCompare(b.time))
                .map((event) => (
                  <Card key={event.id}>
                    <CardContent className="p-4 flex items-center justify-between">
                      <div>
                        <p className="font-medium">{event.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {event.time}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeEvent(event.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </CardContent>
                  </Card>
                ))
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
