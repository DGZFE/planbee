import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Assignment } from "@shared/schema";
import { format } from "date-fns";
import { Clock, CheckCircle2 } from "lucide-react";

interface HomeworkCardProps {
  assignment: Assignment;
  isTeacher?: boolean;
}

export default function HomeworkCard({ assignment, isTeacher }: HomeworkCardProps) {
  const dueDate = new Date(assignment.dueDate);
  const isOverdue = dueDate < new Date();
  const isPending = !isOverdue;

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <CardTitle className="text-lg font-semibold">{assignment.title}</CardTitle>
        <Badge variant={isPending ? "default" : "destructive"}>
          {isPending ? "Pending" : "Overdue"}
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-muted-foreground">{assignment.description}</p>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          Due: {format(dueDate, "PPP")}
        </div>

        {isTeacher ? (
          <div className="flex gap-2">
            <Button variant="outline" size="sm">Edit</Button>
            <Button variant="destructive" size="sm">Delete</Button>
          </div>
        ) : (
          <Button className="w-full" variant={isPending ? "default" : "secondary"}>
            <CheckCircle2 className="h-4 w-4 mr-2" />
            {isPending ? "Submit Assignment" : "View Submission"}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
